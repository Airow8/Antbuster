This is my grade 12 final project. Its a tower defense game where you
have to prevent the ants from stealing your cake.

To run: execute run.sh from the root directory.

Check out some screenshots here: https://github.com/dzelemba/antbusta/wiki/Screenshots.
